<aside id="sidebar" class="sidebar">
	<div class="sidebar-wrapper">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div>
</aside>
