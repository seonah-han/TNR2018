Every day we do our best to make sure [Google Analytics Dashboard for WP (GADWP)](https://deconf.com/google-analytics-dashboard-wordpress/) is safe and secure. But we’re only human, and there’s always a chance that we missed something. That’s where you come in – find a security weakness in our plugin, report it on [HackerOne](https://hackerone.com/deconf_eb9eh), and get listed as a contributor!

To find out more about our security reports policy for the plugin [click here](https://deconf.com/security/).
