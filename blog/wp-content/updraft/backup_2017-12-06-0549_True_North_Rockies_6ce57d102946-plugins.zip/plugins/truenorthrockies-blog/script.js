jQuery(($) => {
  // navigation bar
  $('.site-header').html(`
    <div class="header clearfix">
  		<div class="header-inner">
  			<a href="#" class="menu-button"><span></span></a>
  			<ul class="header-menu no-style el-iblock pull-left">
  				<li><a href="http://truenorthrockies.com">Home</a></li>
  				<li><a href="http://blog.truenorthrockies.com">Blog</a></li>
  				<li><a href="http://truenorthrockies.com/#explore">Activities Guide</a></li>
  				<li><a href="http://truenorthrockies.com/#subscribe">Subscribe</a></li>
  			</ul>
  			<div class="camera-enter text-center">
  				<a href="http://truenorthrockies.com/#contest" class="camera"><i class="fa fa-camera" aria-hidden="true"></i> <span>#WeLoveWinter</span></a>
  			</div>
  			<a href="#" class="header-logo pull-right">
  				<span>presented by</span>
  				<img src="http://truenorthrockies.com/images/header_logo_bgr.png" alt="">
  			</a>
  		</div>
  	</div>
  `)
  $('.site-header').after(`
    <div class="mountain-background">
  	</div>
  `)

  // menu button
  $('.menu-button').on('click', (e) => {
    e.preventDefault()
    $('.menu-button').toggleClass('active')
    $('.header-menu').slideToggle()
  })

  // hero
  const description = (post) => `${post.excerpt.rendered.substr(3, 40)}...`
  const link = (post) => post.link
  $.ajax({
  	url: 'http://blog.truenorthrockies.com/wp-json/wp/v2/posts?per_page=4',
  	type: 'get',
    cache: false,
  	success: (posts) => {
      $('.popular-wrapper').html(`
        <div class="container">
          <div class="logo">
            <img class="logo__image" src="http://truenorthrockies.com/images/logo_bg.png" alt="">
            <h3 class="logo__text">WHERE #WELOVEWINTER</h3>
          </div>
          <div class="tnr-hero">
            <div class="tnr-hero-post" style="margin-bottom: 2px; background: url(${posts[0].better_featured_image.source_url}) center center / cover no-repeat" onclick="window.location = '${link(posts[0])}';">
              <div class="tnr-hero-post__inner">
                <div class="tnr-hero-post__name tnr-hero-post__name--large">${posts[0].title.rendered}</div>
                <div class="tnr-hero-post__description">${description(posts[0])}</div>
                <a class="more-link btn btn-color" href="${link(posts[0])}">Read more...</a>
              </div>
            </div>
            <div style="display: flex;">
              <div class="tnr-hero-post" style="flex: 2; background: url(${posts[1].better_featured_image.source_url}) center center / cover no-repeat" onclick="window.location = '${link(posts[1])}';">
                <div class="tnr-hero-post__inner">
                  <div class="tnr-hero-post__name">${posts[1].title.rendered}</div>
                  <div class="tnr-hero-post__description">${description(posts[1])}</div>
                  <a class="more-link btn btn-color" href="${link(posts[1])}">Read more...</a>
                </div>
              </div>
              <div class="tnr-hero-post" style="flex: 1; margin: 0 2px; background: url(${posts[2].better_featured_image.source_url}) center center / cover no-repeat" onclick="window.location = '${link(posts[2])}';">
                <div class="tnr-hero-post__inner">
                  <div class="tnr-hero-post__name">${posts[2].title.rendered}</div>
                  <div class="tnr-hero-post__description">${description(posts[2])}</div>
                  <a class="more-link btn btn-color" href="${link(posts[2])}">Read more...</a>
                </div>
              </div>
              <div class="tnr-hero-post" style="flex: 1; background: url(${posts[0].better_featured_image.source_url}) center center / cover no-repeat" onclick="window.location = '${link(posts[3])}';">
                <div class="tnr-hero-post__inner">
                  <div class="tnr-hero-post__name">${posts[3].title.rendered}</div>
                  <div class="tnr-hero-post__description">${description(posts[3])}</div>
                  <a class="more-link btn btn-color" href="${link(posts[3])}">Read more...</a>
                </div>
              </div>
            </div>
          </div>
      	</div>
      `)
  	},
    error: (req, status, err) => console.log(err)
  })

  // post logo
  $('.post-standard .post-img').prepend(`
    <div class="logo logo--embedded">
      <img class="logo__image" src="http://truenorthrockies.com/images/logo_bg.png" alt="">
      <h3 class="logo__text">WHERE #WELOVEWINTER</h3>
    </div>
  `)

  // category logo
  $('.page-header').before(`
    <div class="logo" style="margin-top: 20px; margin-bottom: 0;">
      <img class="logo__image" src="http://truenorthrockies.com/images/logo_bg.png" alt="">
      <h3 class="logo__text">WHERE #WELOVEWINTER</h3>
    </div>
  `)

  // $('#single-post-1 > .container > .row-display.grid-2').first().before(`
  //   <div class="row-display grid-1">
  //     <div class="col-12x">
  //       <div class="logo">
  //         <img class="logo__image" src="http://truenorthrockies.com/images/logo_bg.png" alt="">
  //         <h3 class="logo__text">WHERE #WELOVEWINTER</h3>
  //       </div>
  //     </div>
  //   </div>
  // `)
  //
  // const limit = 6
  // const imageSize = $(window).width() / limit
  // const feed = new Instafeed({
  //   get: 'user',
  //   userId: 3943864227,
  //   clientId: '7faab442a78d492cb5799f8eec71f51b',
  //   accessToken: '3943864227.6a3c252.9e0f50e323444a66bcc66047eeef3ff4',
  //   sortBy: 'most-recent',
  //   limit: limit,
  //   resolution: 'standard_resolution',
  //   template: `<a href="{{link}}" target="_blank" style="height: ${imageSize}px; width: ${imageSize}px; background: url({{image}}) center center / cover no-repeat;"></a>`
  // })
  // feed.run()
  //
  // // footer
  // $('.tagcloud a').css('font-size', '14px')
  //
  // // menu button
  // $('.menu-button').on('click', (e) => {
  //   e.preventDefault()
  //   $('.menu-button').toggleClass('active')
  //   $('.header-menu').slideToggle()
  // })
})
