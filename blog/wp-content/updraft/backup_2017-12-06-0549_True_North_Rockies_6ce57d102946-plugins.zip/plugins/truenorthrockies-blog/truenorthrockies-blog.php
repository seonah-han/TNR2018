<?php

/**
* Plugin Name: True North Rockies Blog
* Description: True North Rockies Blog custom functions.
* Author: Lana Ivanova
* Version: 1.0
*/

function quote_shortcode($params, $content, $tag) {
  // normalize attribute keys, lowercase
  $params = array_change_key_case((array)$params, CASE_LOWER);

  // override default attributes with user attributes
  // $my_atts = shortcode_atts([
  //   'message' => 'message',
  // ], $atts, $tag);
  $element = '<div class="tnr-quote">';
  $element .= '<div class="tnr-quote__left" style="background: url(' . $params['image'] . ') center center / cover no-repeat"></div><div class="tnr-quote__right"><div>' . esc_html__($params['message']) . '</div></div>';
  $element .= '</div>';

  ob_start();
  echo $element;
  return ob_get_clean();
}
add_shortcode('quote', 'quote_shortcode');

?>
